using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.IO;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Net;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Cors;
//using System.Web.Http.Cors;

namespace smb.Controllers
{

    class ResponseTypes
    {
       public string sample ;
        public string uri ;
        public string size ;

    }
    [Route("api/upload")]
       
    public class UploadController:Controller
    {
        IConfiguration _configuration;
        public UploadController(IConfiguration configuration)
        {
            _configuration=configuration;
        }

        
 [HttpGet("GetData")]
public async Task<JsonResult> GetData() 
        { 
            String containername = "smbvideolibrary";
            String connectionstring =_configuration.GetConnectionString("azurestorage");
            connectionstring = "DefaultEndpointsProtocol=https;AccountName=smbvideolibrary;AccountKey=1mfBm3q7x7USmH/gBWFEA1pIdgbj3UCNjdlo7umTKsqPOMx2EWXgNIl+a00MkcUamZTDK8q0nPicqUpBbeAOIQ==;EndpointSuffix=core.windows.net";
            CloudStorageAccount storageAccount=CloudStorageAccount.Parse(connectionstring);
         
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            var blobContainer = blobClient.GetContainerReference(containername);

          
            BlobContinuationToken continuationToken = null;
            List<IListBlobItem> results = new List<IListBlobItem>();
            HttpResponseMessage message = new HttpResponseMessage(HttpStatusCode.OK); 
            do
            {
                var response = await blobContainer.ListBlobsSegmentedAsync(continuationToken);
                continuationToken = response.ContinuationToken;
                results.AddRange(response.Results);
            }
            while (continuationToken != null);
        
 
            List<ResponseTypes> objResponseType = new List<ResponseTypes>();
            ResponseTypes objRes;
           
            foreach(CloudBlockBlob re in results)
            {
             objRes = new ResponseTypes();
            objRes.sample  = re.Name.ToString();
            objRes.uri = re.Uri.ToString();
            objRes.size =  re.Properties.Length.ToString();
            if (objRes.uri.EndsWith(".mp4"))
            objResponseType.Add(objRes);
            }
            
            return new JsonResult(objResponseType);
            
        }

        [HttpPost("SaveFile")]
       // async public Task<IActionResult> SaveFile(IFormFile files)
       // public async Task<IHttpActionResult> SaveFile()
       async public Task<IActionResult> SaveFile(IFormFile file)
        {
            var files = Request.Form.Files[0]  ;
            String containername = "smbvideolibrary";
            String connectionstring =_configuration.GetConnectionString("azurestorage");
            connectionstring = "DefaultEndpointsProtocol=https;AccountName=smbvideolibrary;AccountKey=1mfBm3q7x7USmH/gBWFEA1pIdgbj3UCNjdlo7umTKsqPOMx2EWXgNIl+a00MkcUamZTDK8q0nPicqUpBbeAOIQ==;EndpointSuffix=core.windows.net";
            CloudStorageAccount storageAccount=CloudStorageAccount.Parse(connectionstring);
           
            CloudBlobClient blobClient=storageAccount.CreateCloudBlobClient();

            CloudBlobContainer container=blobClient.GetContainerReference(containername);
            await container.CreateIfNotExistsAsync();
            
            CloudBlockBlob blockBlob =container.GetBlockBlobReference(files.FileName);            
            using(var filestream=files.OpenReadStream())
            {
                await blockBlob.UploadFromStreamAsync(filestream);
            }
                        
       return Json (new
        {
            name = blockBlob.Name,
            Uri=blockBlob.Uri,
            size = blockBlob.Properties.Length
        } 
        );
        }
    }
}