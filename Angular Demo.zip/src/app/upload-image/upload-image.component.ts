import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';  
import { ActivatedRoute } from '@angular/router';
import {ResponseType} from './ResponseType';

@Component({
  selector: 'app-upload-image',
  templateUrl: './upload-image.component.html',
  styleUrls: ['./upload-image.component.css']  
  
})
export class UploadImageComponent implements OnInit {
imageUrl :String = "/assets/img/download.jpg";
fileToUpload :File = null;
  
  ngOnInit() {
  }

  handleFileInput(event)  {
   
    //show image preview
    this.fileToUpload=<File> event.target.files[0];
    var reader = new FileReader();
    reader.onload = (event:any) => {
    this.imageUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpload);
  }
  objResponseType: ResponseType[];
  objResponseTypes: ResponseType[];
  results: string
  constructor(private http: HttpClient)
    {

    } 
        
    onUpload()
    {
       var fd: any = new FormData();
       
        fd.append('video',this.fileToUpload,this.fileToUpload.name);
        let apiUrl = 'http://localhost:5000/api/upload/SaveFile';
        console.log('before calling http post webapi');
        console.log(fd);
        console.log(this.fileToUpload + this.fileToUpload.name);
        this.http.post(apiUrl,fd).subscribe(res=>{console.log(res)});
        console.log('after calling http post webapi');

        this.onList();
        
    }
    onList()
    {
      const httpoptions = {headers: new HttpHeaders ({
        'Access-Control-Allow-Origin': '*',
        'Authorization': 'authkey',
        'userid':'1'
      })}
      let apiUrlget = '/api/upload/GetData';
      this.http.get(apiUrlget).subscribe(res => { this.objResponseType = res as ResponseType[]; {console.log(this.objResponseType)}});
      console.log('after calling http get webapi');

    }
    


    }


