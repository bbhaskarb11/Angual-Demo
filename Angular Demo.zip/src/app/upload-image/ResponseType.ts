export class ResponseType
    {
public  sample:string ;
public  uri:string ;
public  size:string ;

    }