import { Injectable } from '@angular/core';  
import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';  
import { Observable } from 'rxjs'; 

//import 'rxjs/add/operator/map';
@Injectable(
  {providedIn:'root'}
)
export class UploadImageComponentService {
  
  constructor(private http: HttpClient)  
    {  
  
    }
    postfile(selectedfile:File)
    {
        const fd = new FormData();
        fd.append('video',selectedfile,selectedfile.name);
        let apiUrl = 'api/Upload/SaveFile';
        //console.log('before calling http post webapi');
        this.http.post(apiUrl,fd).subscribe(res=>{console.log(res)});
       // console.log('after calling http post webapi');
        
    }
     
  }

 


    
